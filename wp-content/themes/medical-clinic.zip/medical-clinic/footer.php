<?php global $mclinic_options;?>
<footer id="site-footer"><!--Start Footer-->
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-6 col-xs-12 os" data-animate="fadeInLeft">
					<div class="footer_item">
						<div class="footer_heading">
							<p>Important links</p>
						</div>
						<ul class="links_item">
							<li><a href="#">Home</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Service</a></li>
							<li><a href="#">Products</a></li>
							<li><a href="#">Contact Us</a></li>
						</ul>
						</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 os" data-animate="fadeInUp">
					<div class="footer_item">
						<div class="footer_heading">
							<p>Contact Us</p>
						</div>
						<div class="footer_contact">
							<div class="contact-info">
								<ul class="list-unstyled">
									<li>
										<i class="fa fa-location-arrow"></i>
										<span>280 Guelph St., Unit 18, Georgetown, ON  L7G 4B1, Canada</span>
									</li>
									<li>
										<i class="fa fa-phone fa-fw"></i>
										<span class="phone_num"><span><strong> Tel:</strong> +(905) 873-3050</span> <span><strong>Fax:</strong> +(905) 873-2129</span>
									</li>
									<li>
										<a href="info@drjoseph.ca">
										<i class="fa fa-envelope fa-fw"></i>
										<span>info@drjoseph.ca</span>
										</a>
									</li>
									<li>
										<a href="http://www.drjoseph.ca/">
											<i class="fa fa-globe fa-fw"></i>
											<span>http://www.drjoseph.ca/</span>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-12 os" data-animate="fadeInRight">
					<div class="footer_item">
						<div class="footer_heading">
							<p>Social link</p>
						</div>
						<div class="social_icon">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="last_footer">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 os" data-animate="fadeInUp">
						<p>Copyright © 2015 Doctor Richard Joseph. All Rights Reserved.<a href="#"> Website by Illusive Design Inc. | Web Design and Web Development.</a></p>
					</div>
				</div>
			</div>
			<div class="bottom_to_top">
				<a onclick="jQuery('html,body').animate({scrollTop:0},'slow');return false;" href="#top">
					<i class="fa fa-angle-up"></i>
				</a>
			</div>
		</div>
	</footer><!--End Footer-->
    </div>     
    <?php wp_footer(); ?>	
  </body>
</html>
