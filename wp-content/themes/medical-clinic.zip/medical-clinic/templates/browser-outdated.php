<?php

/* 
 * @package Condo
 * @subpackage Condo Property
 * @since CondoProperty 1.0
 */
?>
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

