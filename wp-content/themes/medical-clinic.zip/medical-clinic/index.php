<?php
get_header();
?>
      <section id="site-content">
         <?php get_template_part('templates/home', 'slider'); ?>  
         <?php get_template_part('templates/home', 'services'); ?>  
         <?php get_template_part('templates/home', 'doctors'); ?>  
         <?php get_template_part('templates/home', 'products'); ?>  
         <?php get_template_part('templates/home', 'testimonial'); ?>  
      </section> 
<?php
get_footer();
?>