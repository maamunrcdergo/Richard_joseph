<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
add_action('wp_head', 'theme_custom_favicon');
add_action('wp_head', 'theme_apple_touch_icon');
add_action('wp_head', 'theme_humans_txt');
/*
 * add custom  favicon
 */

function theme_custom_favicon() {
  global $mclinic_options;
  if (!empty($mclinic_options['custom_favicon'])) {
    printf('<link rel="shortcut icon" href="%s" type="image/x-icon">', $mclinic_options['custom_favicon']['url']);
    printf('<link rel="icon" href="%s" type="image/x-icon">', $mclinic_options['custom_favicon']['url']);
  }
}

function theme_apple_touch_icon() {
  global $mclinic_options;
  if (!empty($mclinic_options['apple_touch_icon'])) {
    printf('<link rel="apple-touch-icon" href="%s">', $mclinic_options['custom_favicon']['url']);
  }
}

function theme_humans_txt() {
  global $mclinic_options;
  if (!empty($mclinic_options['humans_txt'])) {
    $link = MCLINIC_THEME_URL . '/humans.txt';
    echo "<link rel='author' href='{$link}' />";
  }
}

function theme_primary_menu() {
  wp_nav_menu(array(
    'theme_location' => 'main-menu',
    'container' => 'div',
    'container_class' => 'collapse navbar-collapse menu pull-right',
    'container_id' => 'main_menu',
    'menu_class' => 'nav navbar-nav',
    'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
    'depth' => 4,
    'walker' => new wp_bootstrap_navwalker()
  ));
}
