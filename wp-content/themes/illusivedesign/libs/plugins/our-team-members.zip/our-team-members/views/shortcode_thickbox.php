<?php

  $team_settings = TeamSettings::sharedInstance();

?>

<style type="text/css">
  #team-categories-wrapper,
  #team-order-wrapper,
  #team-template-wrapper {
    margin: 20px 0px;
  }
</style>

<div id="team-categories-wrapper">
  <label for="team-category">Team Category</label>
  <select name="team-category">
    <option value=''>-- Select Category --</option>
    <?php foreach(get_terms('team_category') as $cat): ?>
      <option value="<?php echo $cat->term_id; ?>"><?php echo $cat->name; ?></option>
    <?php endforeach; ?>
  </select>
</div>

<div id="team-order-wrapper">
  <label for="team-order">Team Order</label>
  <select name="team-order">
    <option value=''>-- Use Default --</option>
    <option value="asc">Ascending</option>
    <option value="desc">Descending</option>
  </select>
</div>

<div id="team-template-wrapper">
  <label for="team-template">Team Template</label>
  <select name="team-template">
    <option value=''>-- Use Default --</option>
    <option value='list'>List</option>
    <option value='grid'>Grid</option>
    <?php foreach($team_settings->getCustomTeamTemplates() as $template): ?>
      <option value="<?php echo $template['slug'] ?>">Custom Template <?php echo $template['index']; ?></option>
    <?php endforeach; ?>
  </select>
</div>

<a href="javascript:OurTeam.formatShortCode();" class="button button-primary button-large">Insert Shortcode</a>