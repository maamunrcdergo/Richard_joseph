<?php
/*
Plugin Name: Our Team Members
Plugin URI: https://illusivedesign.ca
Description: Allows Wordpress to keep track of your team for your website. Good for churches, small companies, etc.
Version: 1.0.0
Author: anup @Illusive Design WP Team
Author URI: https://illusivedesign.ca
*/

global $wpdb;
$our_team_table = $wpdb->prefix . 'our_team';

define('OUR_TEAM_TABLE', $wpdb->prefix . 'our_team');
define('TEAM_TEMPLATES', $wpdb->prefix . 'our_team_templates');
define('STAFF_PHOTOS_DIRECTORY', WP_CONTENT_DIR . "/uploads/team-photos/");

require_once(dirname(__FILE__) . '/classes/team_settings.php');

TeamSettings::setupDefaults();

require_once(dirname(__FILE__) . '/classes/our_team.php');
require_once(dirname(__FILE__) . '/classes/our_team_shortcode.php');
require_once(dirname(__FILE__) . '/classes/our_team_admin.php');

OurTeam::register_post_types();
OurTeam::set_default_meta_fields_if_necessary();
OurTeamAdmin::register_admin_menu_items();
OurTeamShortcode::register_shortcode();

if (OurTeam::show_import_message()) {
	//OurTeamAdmin::register_import_old_team_message();
}

register_activation_hook( __FILE__, array('OurTeam', 'set_default_templates_if_necessary'));

?>
