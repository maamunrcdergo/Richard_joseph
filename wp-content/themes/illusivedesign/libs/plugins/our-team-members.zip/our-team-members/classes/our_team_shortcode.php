<?php

class OurTeamShortcode {
  static function register_shortcode() {
    add_shortcode('team-directory', array('OurTeamShortcode', 'shortcode'));
  }

  static function shortcode($params) {
    extract(shortcode_atts(array(
  		'id' => '',
  		'cat' => '',
  		'orderby' => '',
  		'order' => ''
  	), $params));

  	$output = '';

    $team_settings = TeamSettings::sharedInstance();
    if(isset($params['template'])) {
      $template = $params['template'];
    } else {
      $template = $team_settings->getCurrentDefaultTeamTemplate();
    }

  	// get all team
  	$param = "id=$id&cat=$cat&orderby=$orderby&order=$order";
  	return OurTeamShortcode::show_our_team($param, $template);
  }

  static function show_our_team($param = null, $template = NULL){
  	parse_str($param);
  	global $wpdb;

  	// make sure we aren't calling both id and cat at the same time
  	if(isset($id) && $id != '' && isset($cat) && $cat != ''){
  		return "<strong>ERROR: You cannot set both a single ID and a category ID for your Team Directory</strong>";
  	}

    $query_args = array(
      'post_type' => 'team',
      'posts_per_page' => -1
    );

  	// check if it's a single team member first, since single members won't be ordered
  	if((isset($id) && $id != '') && (!isset($cat) || $cat == '')){
      $query_args['p'] = $id;
  	}
  	// ends single team

  	// check if we're returning a team category
  	if((isset($cat) && $cat != '') && (!isset($id) || $id == '')){
  		$query_args['tax_query'] = array(
        array(
          'taxonomy' => 'team_category',
          'terms' => array($cat)
        )
      );
  	}

    if(isset($orderby) && $orderby != ''){
      $query_args['orderby'] = $orderby;
    }
    if(isset($order) && $order != ''){
      $query_args['order'] = $order;
    }

    $team_query = new WP_Query($query_args);

    switch($template){
      case 'list':
        $output = OurTeamShortcode::html_for_list_template($team_query);
        break;
      case 'grid':
        $output = OurTeamShortcode::html_for_grid_template($team_query);
        break;
      default:
        $output = OurTeamShortcode::html_for_custom_template($template, $team_query);
        break;

    }

    wp_reset_query();

  	return $output;
  }

  static function html_for_list_template($wp_query) {
    $output = <<<EOT
      <style type="text/css">
        .clearfix {
          clear: both;
        }
        .single-team {
          margin-bottom: 50px;
        }
        .single-team .photo {
          float: left;
          margin-right: 15px;
        }
        .single-team .photo img {
          max-width: 100px;
          height: auto;
        }
        .single-team .name {
          font-size: 1em;
          line-height: 1em;
          margin-bottom: 4px;
        }
        .single-team .position {
          font-size: .9em;
          line-height: .9em;
          margin-bottom: 10px;
        }
        .single-team .bio {
          margin-bottom: 8px;
        }
        .single-team .email {
          font-size: .9em;
          line-height: .9em;
          margin-bottom: 10px;
        }
        .single-team .phone {
          font-size: .9em;
          line-height: .9em;
        }
        .single-team .website {
          font-size: .9em;
          line-height: .9em;
        }
      </style>
      <div id="team-directory-wrapper">
EOT;
    while($wp_query->have_posts()) {
      $wp_query->the_post();

      $name = get_the_title();
      $position = get_post_meta(get_the_ID(), 'position', true);
      $bio = get_the_content();

      if(has_post_thumbnail()) {
        $attachment_array = wp_get_attachment_image_src(get_post_thumbnail_id());
        $photo_url = $attachment_array[0];
        $photo_html = '<div class="photo"><img src="' . $photo_url . '" /></div>';
      } else {
        $photo_html = '';
      }

      if(get_post_meta(get_the_ID(), 'email', true) != '') {
        $email = get_post_meta(get_the_ID(), 'email', true);
        $email_html = '<div class="email">Email: <a href="mailto:' . $email . '">' . $email . '</a></div>';
      } else {
        $email_html = '';
      }

      if(get_post_meta(get_the_ID(), 'phone', true) != '') {
        $phone_html = '<div class="phone">Phone: ' . get_post_meta(get_the_ID(), 'phone', true) . '</div>';
      } else {
        $phone_html = '';
      }

      if(get_post_meta(get_the_ID(), 'website', true) != '') {
        $website = get_post_meta(get_the_ID(), 'website', true);
        $website_html = '<div class="website">Website: <a href="' . $website . '">' . $website . '</a></div>';
      } else {
        $website_html = '';
      }

      $output .= <<<EOT
        <div class="single-team">
          $photo_html
          <div class="name">$name</div>
          <div class="position">$position</div>
          <div class="bio">$bio</div>
          $email_html
          $phone_html
          $website_html
          <div class="clearfix"></div>
        </div>
EOT;
    }
    $output .= "</div>";
    return $output;
  }

  static function html_for_grid_template($wp_query) {
    $output = <<<EOT
      <style type="text/css">
        .clearfix {
          clear: both;
        }
        .single-team {
          float: left;
          width: 25%;
          text-align: center;
          padding: 0px 10px;
        }
        .single-team .photo {
          margin-bottom: 5px;
        }
        .single-team .photo img {
          max-width: 100px;
          height: auto;
        }
        .single-team .name {
          font-size: 1em;
          line-height: 1em;
          margin-bottom: 4px;
        }
        .single-team .position {
          font-size: .9em;
          line-height: .9em;
          margin-bottom: 10px;
        }
      </style>
      <div id="team-directory-wrapper">
EOT;
    while($wp_query->have_posts()) {
      $wp_query->the_post();

      $name = get_the_title();
      $position = get_post_meta(get_the_ID(), 'position', true);

      if(has_post_thumbnail()) {
        $attachment_array = wp_get_attachment_image_src(get_post_thumbnail_id());
        $photo_url = $attachment_array[0];
        $photo_html = '<div class="photo"><img src="' . $photo_url . '" /></div>';
      } else {
        $photo_html = '';
      }

      $output .= <<<EOT
        <div class="single-team">
          $photo_html
          <div class="name">$name</div>
          <div class="position">$position</div>
        </div>
EOT;
    }
    $output .= "</div>";
    return $output;
  }

  static function html_for_custom_template($template_slug, $wp_query) {
    $team_settings = TeamSettings::sharedInstance();

    $output = '';

    $template = $team_settings->getCustomTeamTemplateForSlug($template_slug);
    $template_html = stripslashes($template['html']);
  	$template_css = stripslashes($template['css']);

  	$output .= "<style type=\"text/css\">$template_css</style>";

    if(strpos($template_html, '[team_loop]')) {
      $before_loop_markup = substr($template_html, 0, strpos($template_html, "[team_loop]"));
      $after_loop_markup = substr($template_html, strpos($template_html, "[/team_loop]") + strlen("[/team_loop]"), strlen($template_html) - strpos($template_html, "[/team_loop]"));
      $loop_markup = str_replace("[team_loop]", "", substr($template_html, strpos($template_html, "[team_loop]"), strpos($template_html, "[/team_loop]") - strpos($template_html, "[team_loop]")));
      $output .= $before_loop_markup;
    } else {
      $loop_markup = $template_html;
    }

    while($wp_query->have_posts()) {
      $wp_query->the_post();

      $team_name = get_the_title();
      if (has_post_thumbnail()) {
        $attachment_array = wp_get_attachment_image_src(get_post_thumbnail_id());
        $photo_url = $attachment_array[0];
        $photo_tag = '<img src="' . $photo_url . '" />';
      } else {
        $photo_url = "";
        $photo_tag = "";
      }

      $team_email = get_post_meta(get_the_ID(), 'email', true);
      $team_email_link = $team_email != '' ? "<a href=\"mailto:$team_email\">Email $team_name</a>" : "";
      $team_phone_number = get_post_meta(get_the_ID(), 'phone_number', true);
      $team_bio = get_the_content();
      $team_website = get_post_meta(get_the_ID(), 'website', true);
      $team_website_link = $team_website != '' ? "<a href=\"$team_website\" target=\"_blank\">View website</a>" : "";

      $team_categories = wp_get_post_terms(get_the_ID(), 'team_category');
      if (count($team_categories) > 0) {
        $team_category = $team_categories[0]->name;
      } else {
        $team_category = "";
      }

      $accepted_single_tags = array("[name]", "[photo_url]", "[bio]", "[category]");
  		$replace_single_values = array($team_name, $photo_url, $team_bio, $team_category);

  		$accepted_formatted_tags = array("[name_header]", "[photo]", "[email_link]", "[bio_paragraph]", "[website_link]");
  		$replace_formatted_values = array("<h3>$team_name</h3>", $photo_tag, $team_email_link, "<p>$team_bio</p>", $team_website_link);

  		$current_team_markup = str_replace($accepted_single_tags, $replace_single_values, $loop_markup);
  		$current_team_markup = str_replace($accepted_formatted_tags, $replace_formatted_values, $current_team_markup);

      preg_match_all("/\[(.*?)\]/", $current_team_markup, $other_matches);
      $team_meta_fields = get_option('team_meta_fields');

      if($team_meta_fields != '' && count($other_matches[0]) > 0) {
        foreach($other_matches[0] as $match) {
          foreach($team_meta_fields as $field) {
            $meta_key = $field['slug'];
            $shortcode_without_brackets = substr($match, 1, strlen($match) - 2);
            if($meta_key == $shortcode_without_brackets) {
              $meta_value = get_post_meta(get_the_ID(), $meta_key, true);
              $current_team_markup = str_replace($match, $meta_value, $current_team_markup);
            }
          }
        }
      }

  		$output .= $current_team_markup;
    }

    if(isset($after_loop_markup)) {
      $output .= $after_loop_markup;
    }

    return $output;
  }
}
