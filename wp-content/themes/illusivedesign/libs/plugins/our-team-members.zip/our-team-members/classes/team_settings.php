<?php

class TeamSettings {
  public static function sharedInstance()
  {
    static $shared_instance = NULL;
    if ($shared_instance === NULL) {
      $shared_instance = new static();
    }
    return $shared_instance;
  }

  public static function setupDefaults() {
    $team_settings = TeamSettings::sharedInstance();

    $current_template_slug = $team_settings->getCurrentDefaultTeamTemplate();
    if($current_template_slug == '' || $current_template_slug == NULL) {
      
      $team_settings->updateDefaultTeamTemplateSlug('list');

    } else if ($current_template_slug == 'custom' || get_option('our_team_html_template', '') != '') {

      $templates_array = array();
      $templates_array[] = array(
        'html' => get_option('our_team_html_template'),
        'css' => get_option('our_team_css_template')
      );
      $team_settings->updateCustomTeamTemplates($templates_array);
      $team_settings->updateDefaultTeamTemplateSlug('custom_1');

      delete_option('our_team_html_template');
      delete_option('our_team_css_template');
      
    }
  }

  #
  # setters
  #

  public function updateDefaultTeamTemplateSlug($slug = 'list') {
    update_option('our_team_template_slug', $slug);
  }

  public function updateCustomTeamTemplates($templates = array()) {
    $updated_templates_array = array();
    $index = 1;
    foreach($templates as $template) {
      if($template['html'] != '' || $template['css'] != '') {
        $template['index'] = $index;
        $template['slug'] = 'custom_' . $index;
        $updated_templates_array[] = $template;
        $index++;
      }
    }
    update_option('our_team_custom_templates', $updated_templates_array);
  }

  public function updateCustomTeamMetaFields($labels = array(), $types = array()) {
    $index = 0;
    $meta_fields_array = array();
    foreach($labels as $meta_label) {
      $slug = strtolower($meta_label);
      $slug = str_replace(' ', '_', $slug);
      if($meta_label != '') {
        $meta_fields_array[] = array(
          'name' => $meta_label,
          'slug' => $slug,
          'type' => $types[$index]
        );
      }
      $index++;
    }
    update_option('team_meta_fields', $meta_fields_array);
  }

  #
  # getters
  #

  public function getCurrentDefaultTeamTemplate() {
    $current_template = get_option('our_team_template_slug');

    if($current_template == '' && get_option('our_team_html_template') != '') {
      update_option('our_team_template_slug', 'custom');
      $current_template = 'custom';
    } else if($current_template == '') {
      update_option('our_team_template_slug', 'list');
      $current_template = 'list';
    }

    return $current_template;
  }

  public function getCustomTeamTemplates() {
    return get_option('our_team_custom_templates', array());
  }

  public function getCustomTeamTemplateForSlug($slug = '') {
    $templates = $this->getCustomTeamTemplates();
    foreach($templates as $template) {
      if($template['slug'] == $slug) {
        return $template;
      }
    }
  }

  public function getTeamDetailsFields() {
    return get_option('team_meta_fields', array());
  }

  #
  # delete functions
  #

  public function deleteCustomTemplate($index = NULL) {
    if($index != NULL) {
      $custom_templates = $this->getCustomTeamTemplates();
      $new_custom_templates == array();
      foreach($custom_templates as $template) {
        if($template['index'] != $index) {
          $new_custom_templates[] = $template;
        }
      }
      $this->updateCustomTeamTemplates($new_custom_templates);
    }
  }
}