<?php

class OurTeamAdmin {
  static function register_admin_menu_items() {
    add_action('admin_menu', array('OurTeamAdmin', 'add_admin_menu_items'));
  }

  static function add_admin_menu_items() {
    add_submenu_page('edit.php?post_type=team', 'Team Directory Settings', 'Settings', 'publish_posts', 'team-directory-settings', array('OurTeamAdmin', 'settings'));
    add_submenu_page('edit.php?post_type=team', 'Team Directory Help', 'Help', 'publish_posts', 'team-directory-help', array('OurTeamAdmin', 'help'));
    //add_submenu_page('edit.php?post_type=team', 'Team Directory Import', 'Import Old Team', 'publish_posts', 'team-directory-import', array('OurTeamAdmin', 'import'));
  }

  static function settings() {

    $team_settings = TeamSettings::sharedInstance();

    if(isset($_GET['delete-template'])) {
      $team_settings->deleteCustomTemplate($_GET['delete-template']);
    }

    if (isset($_POST['team_templates']['slug'])) {
      $team_settings->updateDefaultTeamTemplateSlug($_POST['team_templates']['slug']);
      $did_update_options = true;
    }

    if (isset($_POST['custom_team_templates'])) {
      $team_settings->updateCustomTeamTemplates($_POST['custom_team_templates']);
      $did_update_options = true;
    }

    if (isset($_POST['team_meta_fields_labels'])) {
      $team_settings->updateCustomTeamMetaFields($_POST['team_meta_fields_labels'], $_POST['team_meta_fields_types']);
      $did_update_options = true;
    }

    $current_template = $team_settings->getCurrentDefaultTeamTemplate();
    $custom_templates = $team_settings->getCustomTeamTemplates();

    require_once(plugin_dir_path(__FILE__) . '../views/admin_settings.php');
  }

  static function help() {
    require_once(plugin_dir_path(__FILE__) . '../views/admin_help.php');
  }

  static function import() {
    $did_import_old_team = false;
    if (isset($_GET['import']) && $_GET['import'] == 'true') {
      OurTeam::import_old_team();
      $did_import_old_team = true;
    }
    if (OurTeam::has_old_team_table()):
    ?>

      <h2>Team Directory Import</h2>
      <p>
        This tool is provided to import team from an older version of this plugin.
        This will copy old team members over to the new format, but it is advised
        that you backup your database before proceeding. Chances are you won't need
        it, but it's always better to be safe than sorry! WordPress provides some
        <a href="https://codex.wordpress.org/Backing_Up_Your_Database" target="_blank">instructions</a>
        on how to backup your database.
      </p>

      <p>
        Once you're ready to proceed, simply use the button below to import old
        team members to the newer version of the plugin.
      </p>

      <p>
        <a href="<?php echo get_admin_url(); ?>edit.php?post_type=team&page=team-directory-import&import=true" class="button button-primary">Import Old Team</a>
      </p>

    <?php else: ?>

      <?php if ($did_import_old_team): ?>

        <div class="updated">
          <p>
            Old team was successfully imported! You can <a href="<?php echo get_admin_url(); ?>edit.php?post_type=team">view all team here</a>.
          </p>
        </div>

      <?php else: ?>

        <p>
          It doesn't look like you have any team members from an older version of the plugin. You're good to go!
        </p>

      <?php endif; ?>

    <?php

    endif;
  }

  static function register_import_old_team_message() {
    add_action('admin_notices', array('OurTeamAdmin', 'show_import_old_team_message'));
  }

  static function show_import_old_team_message() {
    ?>

    <div class="update-nag">
      It looks like you have team from an older version of the Team Directory plugin.
      You can <a href="<?php echo get_admin_url(); ?>edit.php?post_type=team&page=team-directory-import">import them</a> to the newer version if you would like.
    </div>

    <?php
  }
}
