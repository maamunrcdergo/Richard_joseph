<?php

class OurTeam {
    #
    # Init custom post types

    #

  static function register_post_types() {
        add_action('init', array('OurTeam', 'create_post_types'));
        add_action('init', array('OurTeam', 'create_team_taxonomies'));
        add_filter("manage_edit-team_columns", array('OurTeam', 'set_team_admin_columns'));
        add_filter("manage_team_posts_custom_column", array('OurTeam', 'custom_team_admin_columns'), 10, 3);
        add_filter("manage_edit-team_category_columns", array('OurTeam', 'set_team_category_columns'));
        add_filter("manage_team_category_custom_column", array('OurTeam', 'custom_team_category_columns'), 10, 3);
        add_filter('enter_title_here', array('OurTeam', 'team_title_text'));
        add_filter('admin_head', array('OurTeam', 'remove_media_buttons'));
        add_action('add_meta_boxes_team', array('OurTeam', 'add_team_custom_meta_boxes'));
        add_action('save_post', array('OurTeam', 'save_meta_boxes'));
        add_action('wp_enqueue_scripts', array('OurTeam', 'enqueue_fontawesome'));
        add_action('admin_enqueue_scripts', array('OurTeam', 'enqueue_fontawesome'));

        add_action('init', array('OurTeam', 'init_tinymce_button'));
        add_action('wp_ajax_get_my_form', array('OurTeam', 'thickbox_ajax_form'));
    }

    static function create_post_types() {
        register_post_type('team', array(
            'labels' => array(
                'name' => __('Team')
            ),
            'supports' => array(
                'title',
                'editor',
                'thumbnail'
            ),
            'public' => true,
            'taxonomies' => array('team_category')
                )
        );
    }

    static function create_team_taxonomies() {
        register_taxonomy('team_category', 'team', array(
            'hierarchical' => true,
            'labels' => array(
                'name' => _x('Team Category', 'taxonomy general name'),
                'singular_name' => _x('team-category', 'taxonomy singular name'),
                'search_items' => __('Search Team Categories'),
                'all_items' => __('All Team Categories'),
                'parent_item' => __('Parent Team Category'),
                'parent_item_colon' => __('Parent Team Category:'),
                'edit_item' => __('Edit Team Category'),
                'update_item' => __('Update Team Category'),
                'add_new_item' => __('Add New Team Category'),
                'new_item_name' => __('New Team Category Name'),
                'menu_name' => __('Team Categories'),
            ),
            'rewrite' => array(
                'slug' => 'team-categories',
                'with_front' => false,
                'hierarchical' => true
            ),
        ));
    }

    static function set_team_admin_columns() {
        $new_columns = array(
            'cb' => '<input type="checkbox" />',
            'title' => __('Title'),
            'id' => __('ID'),
            'featured_image' => __('Featured Image'),
            'date' => __('Date')
        );
        return $new_columns;
    }

    static function custom_team_admin_columns($column_name, $post_id) {
        $out = '';
        switch ($column_name) {
            case 'featured_image':
                $attachment_array = wp_get_attachment_image_src(get_post_thumbnail_id($post_id));
                $photo_url = $attachment_array[0];
                $out .= '<img src="' . $photo_url . '" style="max-height: 60px; width: auto;" />';
                break;

            case 'id':
                $out .= $post_id;
                break;

            default:
                break;
        }
        echo $out;
    }

    static function set_team_category_columns() {
        $new_columns = array(
            'cb' => '<input type="checkbox" />',
            'name' => __('Name'),
            'id' => __('ID'),
            'description' => __('Description'),
            'slug' => __('Slug'),
            'posts' => __('Posts')
        );
        return $new_columns;
    }

    static function custom_team_category_columns($out, $column_name, $theme_id) {
        switch ($column_name) {
            case 'id':
                $out .= $theme_id;
                break;

            default:
                break;
        }
        return $out;
    }

    static function enqueue_fontawesome() {
        wp_enqueue_style('font-awesome', '//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css', array(), '4.0.3');
    }

    #
    # Custom post type customizations

    #

  static function team_title_text($title) {
        $screen = get_current_screen();
        if ($screen->post_type == 'team') {
            $title = "Enter team member's name";
        }

        return $title;
    }

    static function remove_media_buttons() {
        $screen = get_current_screen();
        if ($screen->post_type == 'team') {
            remove_action('media_buttons', 'media_buttons');
        }
    }

    static function add_team_custom_meta_boxes() {
        add_meta_box('team-meta-box', __('Team Details'), array('OurTeam', 'team_meta_box_output'), 'team', 'normal', 'high');
    }

    static function team_meta_box_output($post) {

        wp_nonce_field('team_meta_box_nonce_action', 'team_meta_box_nonce');

        $team_settings = TeamSettings::sharedInstance();
        ?>

        <style type="text/css">
            label.team-label {
                float: left;
                line-height: 27px;
                width: 130px;
            }
        </style>

        <?php foreach ($team_settings->getTeamDetailsFields() as $field): ?>
            <p>
                <label for="team[<?php echo $field['slug'] ?>]" class="team-label"><?php _e($field['name']); ?>:</label>
                <?php if ($field['type'] == 'text'): ?>
                    <input type="text" name="team_meta[<?php echo $field['slug'] ?>]" value="<?php echo get_post_meta($post->ID, $field['slug'], true); ?>" />
                <?php elseif ($field['type'] == 'textarea'): ?>
                    <textarea cols=40 rows=5 name="team_meta[<?php echo $field['slug'] ?>]"><?php echo get_post_meta($post->ID, $field['slug'], true); ?></textarea>
                <?php endif; ?>
            </p>
        <?php endforeach; ?>

        <?php
    }

    static function save_meta_boxes($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;

        if (!isset($_POST['team_meta_box_nonce']) || !wp_verify_nonce($_POST['team_meta_box_nonce'], 'team_meta_box_nonce_action'))
            return;

        if (!current_user_can('edit_post', get_the_id()))
            return;

        foreach (array_keys($_POST['team_meta']) as $meta_field_slug) {
            update_post_meta($post_id, $meta_field_slug, esc_attr($_POST['team_meta'][$meta_field_slug]));
        }
    }

    static function set_default_meta_fields_if_necessary() {
        $current_meta_fields = get_option('team_meta_fields');

        if ($current_meta_fields == NULL || $current_meta_fields = '') {
            $default_meta_fields = array(
                array(
                    'name' => 'Position',
                    'type' => 'text',
                    'slug' => 'position'
                ),
                array(
                    'name' => 'Email',
                    'type' => 'text',
                    'slug' => 'email'
                ),
                array(
                    'name' => 'Phone Number',
                    'type' => 'text',
                    'slug' => 'phone_number'
                ),
                array(
                    'name' => 'Website',
                    'type' => 'text',
                    'slug' => 'website'
                )
            );
            update_option('team_meta_fields', $default_meta_fields);
        }
    }

    #
    # Default templates

    #

  static function set_default_templates_if_necessary() {
        if (get_option('our_team_template_slug') == '') {
            update_option('our_team_template_slug', 'list');
        }

        if (get_option('our_team_html_template') == '') {
            $default_html_template = <<<EOT
<div class="team-directory">

  [team_loop]

    [name_header]
    [bio_paragraph]

    <div class="team-directory-divider"></div>

  [/team_loop]

</div>
EOT;
            update_option('our_team_html_template', $default_html_template);
        }

        if (get_option('our_team_css_template') == '') {
            $default_css_template = <<<EOT
.team-directory-divider{
  border-top: solid black thin;
  width: 90%;
  margin:15px 0;
}
EOT;
            update_option('our_team_css_template', $default_css_template);
        }
    }

    #
    # Related to old team members

    #

  static function has_old_team_table() {
        global $wpdb;
        $our_team_table = $wpdb->prefix . 'our_team';

        $old_team_sql = "SHOW TABLES LIKE '$our_team_table'";
        $old_team_table_results = $wpdb->get_results($old_team_sql);

        return count($old_team_table_results) > 0;
    }

    static function show_import_message() {
        if (
                isset($_GET['page']) &&
                $_GET['page'] == 'team-directory-import' &&
                isset($_GET['import']) &&
                $_GET['import'] == 'true'
        )
            return false;

       // return OurTeam::has_old_team_table();
    }

    static function get_old_team($orderby = null, $order = null, $filter = null) {
        global $wpdb;
        $our_team_table = $wpdb->prefix . 'our_team';
        $our_team_categories = $wpdb->prefix . 'our_team_categories';

        if ((isset($orderby) AND $orderby != '') AND ( isset($order) AND $order != '') AND ( isset($filter) AND $filter != '')) {

            if ($orderby == 'name') {

                $all_team = $wpdb->get_results("SELECT * FROM " . OUR_TEAM_TABLE . " WHERE `category` = $filter ORDER BY `name` $order");
            }

            if ($orderby == 'category') {

                $categories = $wpdb->get_results("SELECT * FROM $our_team_categories WHERE `cat_id` = $filter ORDER BY name $order");

                foreach ($categories as $category) {
                    $cat_id = $category->cat_id;
                    //echo $cat_id;
                    $team_by_cat = $wpdb->get_results("SELECT * FROM " . OUR_TEAM_TABLE . " WHERE `category` = $cat_id");
                    foreach ($team_by_cat as $team) {
                        $all_team[] = $team;
                    }
                }
            }

            return $all_team;
        } elseif ((isset($orderby) AND $orderby != '') AND ( isset($order) AND $order != '')) {

            if ($orderby == 'name') {

                $all_team = $wpdb->get_results("SELECT * FROM " . OUR_TEAM_TABLE . " ORDER BY `name` $order");
            }

            if ($orderby == 'category') {

                $all_team = $wpdb->get_results("SELECT * FROM " . OUR_TEAM_TABLE . " ORDER BY category $order");
            }


            return $all_team;
        } elseif (isset($filter) AND $filter != '') {

            $all_team = $wpdb->get_results("SELECT * FROM " . OUR_TEAM_TABLE . " WHERE `category` = $filter");
            if (isset($all_team)) {
                return $all_team;
            }
        } else {

            return $wpdb->get_results("SELECT * FROM " . OUR_TEAM_TABLE);
        }
    }

    static function import_old_team() {
        global $wpdb;

        $old_categories_table = $wpdb->prefix . 'our_team_categories';
        $old_our_team_table = $wpdb->prefix . 'our_team';
        $old_templates_table = TEAM_TEMPLATES;

        #
        # Copy old categories over first
        #

    $old_team_categories_sql = "
      SELECT
        cat_id, name

      FROM
        $old_categories_table
    ";

        $old_team_categories = $wpdb->get_results($old_team_categories_sql);

        foreach ($old_team_categories as $category) {
            wp_insert_term($category->name, 'team_category');
        }

        #
        # Now copy old team members over
        #

    $old_team = OurTeam::get_old_team();
        foreach ($old_team as $team) {
            $new_team_array = array(
                'post_title' => $team->name,
                'post_content' => $team->bio,
                'post_type' => 'team',
                'post_status' => 'publish'
            );
            $new_team_post_id = wp_insert_post($new_team_array);
            update_post_meta($new_team_post_id, 'position', $team->position);
            update_post_meta($new_team_post_id, 'email', $team->email_address);
            update_post_meta($new_team_post_id, 'phone_number', $team->phone_number);

            if (isset($team->category)) {
                $old_category_sql = "
          SELECT
            cat_id, name

          FROM
            $old_categories_table

          WHERE
            cat_id=$team->category
        ";
                $old_category = $wpdb->get_results($old_category_sql);
                $new_category = get_term_by('name', $old_category[0]->name, 'team_category');
                wp_set_post_terms($new_team_post_id, array($new_category->term_id), 'team_category');
            }

            if (isset($team->photo) && $team->photo != '') {
                $upload_dir = wp_upload_dir();
                $upload_dir = $upload_dir['basedir'];
                $image_path = $upload_dir . '/team-photos/' . $team->photo;
                $filetype = wp_check_filetype($image_path);
                $attachment_id = wp_insert_attachment(array(
                    'post_title' => $team->photo,
                    'post_content' => '',
                    'post_status' => 'publish',
                    'post_mime_type' => $filetype['type']
                        ), $image_path, $new_team_post_id);
                set_post_thumbnail($new_team_post_id, $attachment_id);
            }
        }

        #
        # Now copy templates over
        #

    $old_html_template_sql = "
      SELECT
        template_code

      FROM
        $old_templates_table

      WHERE
        template_name='team_index_html'
    ";
        $old_html_template_results = $wpdb->get_results($old_html_template_sql);
        update_option('our_team_html_template', $old_html_template_results[0]->template_code);

        $old_css_template_sql = "
      SELECT
        template_code

      FROM
        $old_templates_table

      WHERE
        template_name='team_index_css'
    ";
        $old_css_template_results = $wpdb->get_results($old_css_template_sql);
        update_option('our_team_css_template', $old_css_template_results[0]->template_code);

        #
        # Now delete the old tables
        #

    $drop_tables_sql = "
      DROP TABLE
        $old_categories_table, $old_our_team_table, $old_templates_table
    ";
        $wpdb->get_results($drop_tables_sql);
    }

    static function init_tinymce_button() {
        if (!current_user_can('edit_posts') && !current_user_can('edit_pages') && get_user_option('rich_editing') == 'true')
            return;

        add_filter("mce_external_plugins", array('OurTeam', 'register_tinymce_plugin'));
        add_filter('mce_buttons', array('OurTeam', 'add_tinymce_button'));
    }

    static function register_tinymce_plugin($plugin_array) {
        $plugin_array['our_team_button'] = plugins_url('/../js/shortcode.js', __FILE__);
        ;
        return $plugin_array;
    }

    static function add_tinymce_button($buttons) {
        $buttons[] = "our_team_button";
        return $buttons;
    }

    static function thickbox_ajax_form() {
        require_once(plugin_dir_path(__FILE__) . '/../views/shortcode_thickbox.php');
        exit;
    }

}
