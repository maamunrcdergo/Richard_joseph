jQuery(document).ready(function($) {
  tinymce.create('tinymce.plugins.our_team_shortcode_plugin', {
    init : function(ed, url) {
      ed.addCommand('our_team_insert_shortcode', function() {
        tb_show('Team Directory Shortcode Options', 'admin-ajax.php?action=get_my_form');
      });
      ed.addButton('our_team_button', {title : 'Insert Team Directory Shortcode', cmd : 'our_team_insert_shortcode', image: url + '/../images/wp-editor-icon.png' });
    },
  });
  tinymce.PluginManager.add('our_team_button', tinymce.plugins.our_team_shortcode_plugin);
});

OurTeam = {
  formatShortCode: function(){
    var categoryVal = jQuery('[name="team-category"]').val();
    var orderVal = jQuery('[name="team-order"]').val();
    var templateVal = jQuery('[name="team-template"]').val();
    
    var shortcode = '[team-directory';

    if(categoryVal != '') {
      shortcode += ' cat=' + categoryVal;
    }

    if(orderVal != '') {
      shortcode += ' order=' + orderVal;
    }

    if(templateVal != '') {
      shortcode += ' template=' + templateVal;
    }

    shortcode += ']';
    
    tinymce.execCommand('mceInsertContent', false, shortcode);
    tb_remove();
  }
};